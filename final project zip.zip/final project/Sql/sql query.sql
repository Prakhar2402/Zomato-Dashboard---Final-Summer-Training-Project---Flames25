use zomato;
CREATE TABLE zomato (
    `Restaurant_ID` INT,
    `Restaurant_Name` VARCHAR(255),
    `Country_Code` INT,
    `Country_Name` VARCHAR(100),
    `City` VARCHAR(100),
    `Address` TEXT,
    `Locality` VARCHAR(150),
    `Locality_Verbose` VARCHAR(255),
    `Longitude` VARCHAR(50),
    `Latitude` VARCHAR(50),
    `Cuisines` VARCHAR(255),
    `Average_Cost_for_two` VARCHAR(50),
    `Currency` VARCHAR(50),
    `Cost_in_INR` VARCHAR(50),
    `Has_Table_booking` VARCHAR(10),
    `Has_Online_delivery` VARCHAR(10),
    `Is_delivering_now` VARCHAR(10),
    `Switch_to_order_menu` VARCHAR(10),
    `Price_range` VARCHAR(10),
    `Aggregate_rating` VARCHAR(10),
    `Rating_color` VARCHAR(20),
    `Rating_text` VARCHAR(50),
    `Votes` VARCHAR(50),
    `Votes_values_are_nos` VARCHAR(50),
    `avg_if_negative` VARCHAR(50),
    `Rating_Category` VARCHAR(50)
);


LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/final_zomato_dataset_for_sql_powerbi.csv'
INTO TABLE zomato
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- 1. Total Number of Restaurants per Country

SELECT Country_Name, COUNT(*) AS total_restaurants
FROM zomato
GROUP BY Country_Name
ORDER BY total_restaurants DESC;

-- 2. Top Cities by Restaurant Count
SELECT City, COUNT(*) AS total_restaurants
FROM zomato
GROUP BY City
ORDER BY total_restaurants DESC
LIMIT 10;

-- 3. Percentage of Restaurants Offering Online Delivery per Country
SELECT Country_Name,
       ROUND(SUM(CASE WHEN Has_Online_delivery = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS online_delivery_percentage
FROM zomato
GROUP BY Country_Name
ORDER BY online_delivery_percentage DESC;

-- 4.Most Common Cuisines
SELECT Cuisines, COUNT(*) AS count
FROM zomato
GROUP BY Cuisines
ORDER BY count DESC
LIMIT 10;

-- 5.Top 5 Cities per Country by Number of Restaurants
SELECT z.Country_Name, z.City, z.restaurant_count
FROM (
    SELECT Country_Name, City, COUNT(*) AS restaurant_count,
           ROW_NUMBER() OVER (PARTITION BY Country_Name ORDER BY COUNT(*) DESC) AS city_rank
    FROM zomato
    GROUP BY Country_Name, City
) AS z
WHERE z.city_rank <= 5
ORDER BY z.Country_Name, z.restaurant_count DESC;

-- 6. Join Subquery to Show Country-Wise Average Cost and Rating
SELECT z.Country_Name, 
       ROUND(AVG(CAST(z.Average_Cost_for_two AS UNSIGNED)), 2) AS avg_cost,
       ROUND(AVG(CAST(z.Aggregate_rating AS DECIMAL(3,2))), 2) AS avg_rating
FROM zomato z
WHERE z.Average_Cost_for_two != '' AND z.Aggregate_rating != 'Not rated'
GROUP BY z.Country_Name
ORDER BY avg_rating DESC;

-- 7.Countries Where Restaurants Have the Highest Votes on Average
SELECT Country_Name,
       ROUND(AVG(CAST(Votes AS UNSIGNED)), 2) AS avg_votes
FROM zomato
WHERE Votes != ''
GROUP BY Country_Name
ORDER BY avg_votes DESC;

CREATE VIEW top_cities_per_country AS
SELECT z.Country_Name, z.City, z.restaurant_count
FROM (
    SELECT Country_Name, City, COUNT(*) AS restaurant_count,
           ROW_NUMBER() OVER (PARTITION BY Country_Name ORDER BY COUNT(*) DESC) AS city_rank
    FROM zomato
    GROUP BY Country_Name, City
) AS z
WHERE z.city_rank <= 5;


-- for exporting dataset from here
SELECT *
FROM zomato
INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/final_zomato_after_sql.csv'
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"' 
LINES TERMINATED BY '\n';



