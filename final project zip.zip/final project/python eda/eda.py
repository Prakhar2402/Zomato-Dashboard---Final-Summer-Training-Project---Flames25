# 🔹 Step 1: Import Libraries
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix


sns.set_style('whitegrid')

# 🔹 Step 2: Load the Cleaned Dataset
df = pd.read_excel("C:\\Users\\asus\\OneDrive\\Desktop\\K23GP\\summer training\\final project\\cleaned_zomato.xlsx")

# 🔹 Step 3: Quick Dataset Overview
print(df.shape)
print(df.columns)
print(df.info())
print(df.describe())
print(df.isnull().sum())


#  1. Top 5 countries by number of restaurants
top_countries = df['Country Name'].value_counts().head(5)
top_countries.plot(kind='bar', figsize=(10,5), color='skyblue')
plt.title("Top 5 Countries by Restaurant Count")
plt.ylabel("Count")
plt.xticks(rotation=45)
plt.show()

#  2. Top 5 cities by number of restaurants
top_cities = df['City'].value_counts().head(5)
sns.barplot(x=top_cities.values, y=top_cities.index, palette='magma')
plt.title("Top 5 Cities by Restaurant Count")
plt.xlabel("Restaurants")
plt.ylabel("City")
plt.show()

#  3. Top 10 cuisines overall
cuisines = df['Cuisines'].dropna().str.split(',').explode().str.strip()
top_cuisines = cuisines.value_counts().head(10)
sns.barplot(x=top_cuisines.values, y=top_cuisines.index, palette='viridis')
plt.title("Top 10 Cuisines Offered")
plt.xlabel("Count")
plt.ylabel("Cuisine")
plt.show()

#  4. Distribution of aggregate ratings
sns.histplot(df['Aggregate rating'], bins=20, kde=True, color='green')
plt.title("Aggregate Rating Distribution")
plt.xlabel("Rating")
plt.ylabel("Number of Restaurants")
plt.show()

#  5. Online delivery availability
delivery = df['Has Online delivery'].value_counts()
plt.pie(delivery, labels=delivery.index, autopct='%1.1f%%', colors=['lightgreen','lightcoral'])
plt.title("Online Delivery Availability")
plt.show()

#  6. Table booking availability
booking = df['Has Table booking'].value_counts()
sns.barplot(x=booking.index, y=booking.values, palette='Set2')
plt.title("Table Booking Availability")
plt.ylabel("Count")
plt.show()

#  7. Average cost for two by country
avg_cost = df.groupby('Country Name')["Average Cost for two"].mean().sort_values(ascending=False).head(5)
avg_cost.plot(kind='bar', figsize=(10,5), color='orange')
plt.title("Avg Cost for Two by Country (Top 5)")
plt.ylabel("Avg Cost")
plt.xticks(rotation=45)
plt.show()

#  8. Price range distribution
sns.countplot(x='Price range', data=df, palette='coolwarm')
plt.title("Distribution of Price Ranges")
plt.xlabel("Price Range")
plt.ylabel("Restaurant Count")
plt.show()

#  9. Most voted restaurants
most_voted = df[df['Votes'] > 0].sort_values(by='Votes', ascending=False).head(10)
sns.barplot(x=most_voted['Votes'], y=most_voted['Restaurant Name'], palette='flare')
plt.title("Top 10 Most Voted Restaurants")
plt.xlabel("Votes")
plt.ylabel("Restaurant")
plt.show()

# 10. Top 10 Localities with Most Restaurants
top_localities = df['Locality'].value_counts().head(10)
sns.barplot(x=top_localities.values, y=top_localities.index, palette='crest')
plt.title("Top 10 Localities with Most Restaurants")
plt.xlabel("Restaurant Count")
plt.ylabel("Locality")
plt.show()

# 11. Restaurant Location Distribution (Approx.)
sns.scatterplot(x='Longitude', y='Latitude', hue='Country Name', data=df, alpha=0.6)
plt.title("Restaurant Location Distribution (Approx.)")
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.show()

# 12. Rating Text Distribution
sns.countplot(data=df, x='Rating text', order=df['Rating text'].value_counts().index, palette='pastel')
plt.title("Distribution of Rating Text Labels")
plt.xlabel("Rating Category")
plt.ylabel("Restaurant Count")
plt.xticks(rotation=45)
plt.show()

# 13. Heatmap of Country vs Price Range
pivot = pd.crosstab(df['Country Name'], df['Price range'])
sns.heatmap(pivot, annot=True, cmap='YlGnBu', fmt='g')
plt.title("Country vs Price Range")
plt.xlabel("Price Range")
plt.ylabel("Country")
plt.show()


# 14. Top 10 Countries by Cuisine Variety
# cuisines into separate rows
df_cuisine = df[['Country Name', 'Cuisines']].dropna()
df_cuisine = df_cuisine.assign(Cuisine=df_cuisine['Cuisines'].str.split(',')).explode('Cuisine')
df_cuisine['Cuisine'] = df_cuisine['Cuisine'].str.strip()

# crosstab of Country vs Cuisine
cuisine_country = pd.crosstab(df_cuisine['Country Name'], df_cuisine['Cuisine'])

# Count how many unique cuisines per country
top_cuisine_country = (cuisine_country > 0).sum(axis=1).sort_values(ascending=False).head(10)

top_cuisine_country.plot(kind='barh', color='slateblue')
plt.title("Top 10 Countries by Cuisine Variety")
plt.xlabel("Unique Cuisine Count")
plt.ylabel("Country")
plt.show()

# Visual check for outliers
sns.boxplot(data=df[['Votes', 'Average Cost for two']])
plt.title("Boxplot for Votes and Cost")
plt.show()

# Function to remove outliers using IQR method
def remove_outliers_iqr(data, column):
    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    return data[(data[column] >= lower) & (data[column] <= upper)]

# Apply outlier removal on selected numerical columns
df = remove_outliers_iqr(df, 'Votes')
df = remove_outliers_iqr(df, 'Average Cost for two')

# Prepare features and encode target variable
features = df[['Votes', 'Average Cost for two', 'Price range']]
le = LabelEncoder()
df['Rating Category'] = le.fit_transform(df['Rating text'])
target = df['Rating Category']

# Split data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# Train KNN classifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)
y_pred_knn = knn.predict(X_test)

# Evaluate KNN model
print("KNN Classification Report:")
print(classification_report(y_test, y_pred_knn))
print("KNN Confusion Matrix:")
print(confusion_matrix(y_test, y_pred_knn))

# Train Decision Tree classifier
dt = DecisionTreeClassifier(max_depth=5, random_state=42)
dt.fit(X_train, y_train)
y_pred_dt = dt.predict(X_test)

# Evaluate Decision Tree model
print("Decision Tree Classification Report:")
print(classification_report(y_test, y_pred_dt))
print("Decision Tree Confusion Matrix:")
print(confusion_matrix(y_test, y_pred_dt))

# Plot feature importance from Decision Tree
importances = dt.feature_importances_
features_list = features.columns

sns.barplot(x=importances, y=features_list)
plt.title("Feature Importance - Decision Tree")
plt.xlabel("Importance Score")
plt.ylabel("Feature")
plt.show()


# Export final cleaned and transformed dataset
df.to_csv("final_zomato_utf8.csv", index=False, encoding='utf-8')
